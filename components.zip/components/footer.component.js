import React from 'react'
import '../css/style2.css'



export default class Footer extends React.Component {
    render() {
        return (
            <footer className="footer">
                <div className="Container">
                        <h4>Follow us.</h4>
                        <p style={{"marginBottom": "0" }} >Traimbak Bhat &emsp; | &emsp; Vyshak R &emsp; | &emsp; </p>
                        <a href="https://www.facebook.com"><i id="social-fb" className="fa fa-facebook-square fa-3x social"></i></a>
                        <a href="https://twitter.com"><i id="social-tw" className="fa fa-twitter-square fa-3x social"></i></a>
                        <a href="https://www.instagram.com"><i id="social-ig" className="fa fa-instagram fa-3x social"></i></a>
                        <a href="srvyshak@gmail.com"><i id="social-em" className="fa fa-envelope-square fa-3x social"></i></a>
                </div>
            </footer>
        )
    }
}

