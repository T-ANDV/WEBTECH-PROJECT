var Auth = {
    userName: null,
    userLoged: false
};
export { Auth };